@include('layouts.admin.head')
@section('titulo','Admin')

<main>
    <h1>Admin</h1>

</main>

@include('layouts.admin.foot')