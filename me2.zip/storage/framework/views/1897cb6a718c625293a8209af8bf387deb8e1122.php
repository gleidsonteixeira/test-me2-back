<?php echo $__env->make('layouts.site.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
$("title").text("Ajuda");
$('.favicon').attr("href", '<?php echo e(asset("assets/admin/images/icone.png")); ?>');
</script>

<?php echo $__env->make('layouts.site.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main>

    <section id="head">
        <h1>Ajuda</h1>
    </section>

</main>

<?php echo $__env->make('layouts.site.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linkdebio\resources\views/site/ajuda.blade.php ENDPATH**/ ?>