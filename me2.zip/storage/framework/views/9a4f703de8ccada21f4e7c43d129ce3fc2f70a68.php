

</body>
</html><?php /**PATH C:\xampp\htdocs\linkdebio\resources\views/layouts/admin/foot.blade.php ENDPATH**/ ?>