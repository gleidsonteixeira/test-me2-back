<?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('titulo','Perfis'); ?>

<main>
    <h1>Perfis</h1>

</main>

<?php echo $__env->make('layouts.admin.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linkdebio\resources\views/admin/perfis.blade.php ENDPATH**/ ?>