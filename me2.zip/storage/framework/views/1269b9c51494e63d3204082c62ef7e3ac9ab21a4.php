<?php echo $__env->make('layouts.site.head-pagina', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
$("title").text("Login");
</script>

<main>
    <section id="cadastro-forms">
        <form id="cadastro" method="POST" action="<?php echo e(route('login')); ?>">
            <label>Seu email</label>
            <input type="text" name="email" required>
            <label>Sua senha</label>
            <input type="password" name="password" required>
            <button type="submit" class="click suave"><span class="suave">Entrar</span></button>
        </form>
    </section>
</main><?php /**PATH C:\xampp\htdocs\linkdebio\resources\views/site/login.blade.php ENDPATH**/ ?>