<?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('titulo','Admin'); ?>

<main>
    <h1>Admin</h1>

</main>

<?php echo $__env->make('layouts.admin.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\linkdebio\resources\views/admin/index.blade.php ENDPATH**/ ?>