@include('layouts.admin.head')
@section('titulo','Perfis')

<main>
    <h1>Perfis</h1>

</main>

@include('layouts.admin.foot')